# Author: Jeremy Cordero Martinez
# 2D Pygame: A Fox's Quest
import pygame
import sys
# It will import general settings and constants that we going to be using through out the game
from items.settings import gameWidth, gameHeight,framesPerSecond,backgroundColors,colorWhite,GameHudColor,levelstimeLimit
# It will import sprites classes for items such as the goal (picnic), colectable platforms
from items.assets import Berry, Picknic, Platforms
# It will import the timer class to manage the games level countdown
from items.timer import levelsTimer
# It will import player character (Foxy) and the enemy classes (the forest animals)
from clases.foxy import Foxy
from clases.animals import Deer, Rabbit, Bear
# Game states:
# These strings are used as identifiers for what "screen" the game is going to say
gameMenu = "Lets see what we have here little fox"
playing = "¡Keep running little fox!"
gameOver = "Guess we are going hungry tonight little fox :("
victory = "¡OHH we are eating good tonight little fox :)!"
pausedMenu = "Take quick nap little fox"
# Main Game class:
class Game:
     # We initialize pygame and create window and of the game clock that will control the games framerate
    def __init__(self):
        pygame.init()
        self.window = pygame.display.set_mode((gameWidth,gameHeight))
        pygame.display.set_caption(" A Fox's Quest ")
        self.clock = pygame.time.Clock()
        # Game Fonts
        try:
            # We try to load custom font for title and HUD of the game
         self.font = pygame.font.Font("ForestRoad-0WPyv.otf", 32)
         self.hudFont = pygame.font.Font("ForestRoad-0WPyv.otf", 24)
        except:
            # If custom font is not found, we use a system font
         self.font = pygame.font.SysFont("Times New Roman", 32)
         self.hudFont = pygame.font.SysFont("Times New Roman", 24)
         # Menu background image we also scale it to fit the game window
        try:
            self.tittleBackground = pygame.image.load("TittleBackground.png").convert()
            self.tittleBackground = pygame.transform.scale(self.tittleBackground,(gameWidth,gameHeight))
        except: 
             # If loading fails, we will draw a solid-color background instead
            self.tittleBackground = None
        # In-game background image, we also scale it to fit the game window
        try:
            self.Background = pygame.image.load("ForestBackground.png").convert()
            self.Background = pygame.transform.scale(self.Background,(gameWidth,gameHeight))
        except: 
            self.Background = None
        # Slash image for fox attack, we also scale it to fit the fox size
        try:
            slashImg = pygame.image.load("slash.png").convert_alpha()
            self.slashImage = pygame.transform.scale(slashImg, (90, 90))
        except Exception:
            # in case the image does not load a small white rectangle will be used
            self.slashImage = pygame.Surface((60, 20), pygame.SRCALPHA)
            self.slashImage.fill((255, 255, 255, 200))

       # States for showing the slash effect
        self.slashActive = False  # Is the slash currently invisible? until we attack
        self.slashStartTime = 0   # When the slash starts being shown
        self.slashDuration = 120  # How long to show the slash 
        self.slashRect = self.slashImage.get_rect()  # Rect used for positioning

        self.GMState = gameMenu  # Current global state of the game
         # Sprite groups to organize and draw/update everything
        self.allTheGameSprites = pygame.sprite.Group() # All game sprites
        self.platforms = pygame.sprite.Group() # Platforms group
        self.animals =  pygame.sprite.Group() # Forest animals group
        self.berries =  pygame.sprite.Group() # Berries group
        self.goals =  pygame.sprite.Group() # Goal (picnic) group
        self.showControlsInfo = False # Whether the controls popup should be visible in the menu
        # Player and level timer reference
        self.foxy = None
        self.timer = levelsTimer(levelstimeLimit) 
        # The game sound effects
        self.jumpSound = None
        self.hitSound = None 
        self.pickUpSound = None
        self.foxSlash = None
        
        self.lastTimeFoxyGotHit = 0  # The last time foxy got hit by an animal
        self.damageCooldown = 700  # Invicibelity frames
        # Load assets and set up the level
        self.loadAssests()
        self.resetThelevel()
    # Load music and sound effects   
    def loadAssests(self):
        # Background music
        try:
         pygame.mixer.music.load("forestMusic.mp3")
         pygame.mixer.music.play(-1) # Loop the music indefinitely
        except:
            print("The Background music was not found")
        # Sound effects
        try:
            self.jumpSound = pygame.mixer.Sound("jump.mp3")
        except:
            self.jumpSound = None
        # Hit sound effect
        try:
            self.hitSound = pygame.mixer.Sound("hit.mp3")
        except:
            self.hitSound = None
        # Slash sound effect
        try:
            self.foxSlash = pygame.mixer.Sound("Slash.mp3")
        except:
            self.foxSlash = None
        # Pickup sound effect
        try:
            self.pickUpSound = pygame.mixer.Sound("pickup.mp3")
        except:
            self.pickUpSound = None
    # Resets the level to its initial state            
    def resetThelevel(self):
        # Clears all sprite groups
        self.allTheGameSprites.empty() # All sprites
        self.platforms.empty() # Platforms group
        self.animals.empty() # Forest animals group
        self.berries.empty() # Berries group
        self.goals.empty() # Goal (picnic) group
        # Creates player (Foxy) and adds to all sprites group
        self.foxy = Foxy(100,380) # CreateS foxy
        self.allTheGameSprites.add(self.foxy) # Adds foxy to all sprites group
        playground = Platforms(0, gameHeight - 40, gameWidth, 40) # ground platform
        self.platforms.add(playground)# Adds ground to platforms group
        self.allTheGameSprites.add(playground)# Adds ground to all sprites group
        # Creates and place platforms
        platformPlacement = [
           (150, 500, 200, 20),
           (400, 420, 200, 20),
           (650, 350, 200, 20),
        ]
        orderedPlatforms = [] # keeps track of created platforms
        # Creates the platforms and add them to groups
        for a,b,c,d in platformPlacement:
            platform = Platforms(a,b,c,d)
            orderedPlatforms.append(platform)
            self.platforms.add(platform)
            self.allTheGameSprites.add(platform)
        
        # Creates animals and add them to groups
        animalsAtributes =  [   
            (Rabbit,orderedPlatforms[0]),
            (Deer, orderedPlatforms[1]),
            (Bear, orderedPlatforms[2])
        ]
        # Creates the animals and add them to groups
        for enemyClass, platform in animalsAtributes:
            px = platform.rect.centerx
            # Make them walk between left & right ends of platform
            enemy = enemyClass(px, 0, platform.rect.left, platform.rect.right)
            enemy.rect.bottom = platform.rect.top  # places them on the platform
            # A Special handling for Rabbit to set its baseY for hopping animation
            if isinstance(enemy, Rabbit):
                enemy.baseY = enemy.rect.y
            self.animals.add(enemy)
            self.allTheGameSprites.add(enemy)
        # Creates berries and add them to groups    
        for p in orderedPlatforms:
            berry = Berry(p.rect.centerx, p.rect.top - 35) # places the berry above platform
            self.berries.add(berry)
            self.allTheGameSprites.add(berry)
        # Creates the goal (picnic) and add to groups
        goal = Picknic(gameWidth -210, gameHeight - 270)
        self.goals.add(goal)
        self.allTheGameSprites.add(goal)
        # Resets the level timer
        self.timer.resetTimer(levelstimeLimit)
        # Resets foxy's lives and score
        self.foxy.Plives = 3
        self.foxy.Pscore = 0
        
    # The main game loop that runs the different game states depending on the current GMState
    def runningTheGame(self):
        while True:
            if self.GMState == gameMenu:# Show the main menu
                self.menuLoop()
            elif self.GMState == playing:# Play the game
                self.playingLoop()
            elif self.GMState == gameOver:# Game over state
                self.gameOverLoop()
            elif self.GMState == pausedMenu:# Paused menu state
                self.pausedLoop()
            elif self.GMState == victory:# Victory state
                self.victoryLoop()
            else: # if the state is unknown, then go back to menu
                self.GMState = gameMenu
    # Starts the game     
    def run(self):
        self.runningTheGame() 
    # Handles the different game state loops         
    def menuLoop(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:# Quit event
                pygame.quit()
                sys.exit()
            # Any key press starts the game or toggles controls info
            if event.type == pygame.KEYDOWN:
              if self.showControlsInfo:
                  self.showControlsInfo = False
              else:
                  if event.key == pygame.K_h:# Show controls info
                     self.showControlsInfo = True
                  else:
                     self.resetThelevel()
                     self.GMState = playing
        
        if self.tittleBackground:# Draw menu background
            self.window.blit(self.tittleBackground, (0, 0))
        else:
            self.window.fill((10, 20, 30)) # Solid color background
        
        gametitle = self.font.render(" A Fox's Quest ", True, colorWhite) # Game title is rendered
        prompt = self.font.render("Press any key to start the game", True, GameHudColor) # Start indication prompts
        helpTextBox = self.hudFont.render("Press H to learn or check the controls", True, GameHudColor)# The help prompt
        
                # Draws the main menu text centered on the screen
        self.window.blit(gametitle, (gameWidth // 2 - gametitle.get_width() // 2, gameHeight // 3))
        self.window.blit(prompt, (gameWidth // 2 - prompt.get_width() // 2, gameHeight // 2))
        self.window.blit(helpTextBox, (gameWidth // 2 - helpTextBox.get_width() // 2, gameHeight // 2 + 40))

        #  shows a pop-up window with the controls
        if self.showControlsInfo:
            widthOfThePopUp = 700
            heightOfThePopUp = 360

            # Semi-transparent black background for the pop-up
            popUpSurface = pygame.Surface((widthOfThePopUp, heightOfThePopUp), pygame.SRCALPHA)
            popUpSurface.fill((0, 0, 0, 200))

            # Lines of text for the control instructions
            controls = [
                "",
                "Game Controls:",
                "Move left: <-- or A",
                "Move right: --> or D",
                "Jump: J, ^ or W",
                "Attack: Space Bar",
                "Pause: P",
                "Main menu: ESC",
                "",
                "Press any key to close this window"
            ]

            y = 20
            for i, text in enumerate(controls):
                # First line (empty or title) uses bigger font
                if i == 0:
                    textSurface = self.font.render(text, True, colorWhite)
                else:
                    textSurface = self.hudFont.render(text, True, colorWhite)

                # Center each line inside the pop-up
                popUpSurface.blit(
                    textSurface,
                    (widthOfThePopUp // 2 - textSurface.get_width() // 2, y)
                )
                y += textSurface.get_height() + 5

            # Center the pop-up on the screen
            popUpX = gameWidth // 2 - widthOfThePopUp // 2
            popUpY = gameHeight // 2 - heightOfThePopUp // 2
            self.window.blit(popUpSurface, (popUpX, popUpY))

        # Updates display and keep FPS stable
        pygame.display.flip()
        self.clock.tick(framesPerSecond)

    
    # Main gameplay loop, it handles input, updates objects, checks collisions, and draws the game while playing
    def playingLoop(self):
        # Handle all events for this frame
        for E in pygame.event.get():
            if E.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Handles pause and going back to menu
            if E.type == pygame.KEYDOWN:
                if E.key == pygame.K_ESCAPE:
                    self.GMState = gameMenu
                elif E.key == pygame.K_p:
                    self.GMState = pausedMenu

                # Attacks with spacebar
                if E.key == pygame.K_SPACE:
                    defeatedAnimalCount = self.foxy.foxyAttack(self.animals)

                    # Play slash sound if at least one enemy was hit
                    if defeatedAnimalCount is not None and defeatedAnimalCount > 0 and self.foxSlash:
                        self.foxSlash.play()

                    # Turn on visual slash effect for a brief moment
                    self.slashActive = True
                    self.slashStartTime = pygame.time.get_ticks()

                    # Put the slash slightly in front of Foxy (to the right for now)
                    self.slashRect.centerx = self.foxy.rect.centerx + 40
                    self.slashRect.centery = self.foxy.rect.centery

        # Handles player inputs for movement and jumping
        self.foxy.handleThePlayersInputs()

        # Update player and enemies
        self.foxy.update(self.platforms)
        self.animals.update()

        # If time runs out, the game is over
        if self.timer.gameTimeIsUP():
            self.GMState = gameOver

        # Check collisions between Foxy and enemies (damage)
        damage = pygame.sprite.spritecollide(self.foxy, self.animals, False)
        if damage:
            rightNow = pygame.time.get_ticks()
            # Only take damage if enough time has passed since last hit (invincibility frames)
            if rightNow - self.lastTimeFoxyGotHit > self.damageCooldown:
                totalDamage = 0
                for forestAnimal in damage:
                    totalDamage += forestAnimal.damage
                    if self.hitSound:
                        self.hitSound.play()

                self.foxy.Plives -= totalDamage
                self.lastTimeFoxyGotHit = rightNow

                # If Foxy runs out of lives, game over
                if self.foxy.Plives <= 0:
                    self.GMState = gameOver

        # Checks if Foxy collects any berries
        collectedBerries = pygame.sprite.spritecollide(self.foxy, self.berries, True)
        if collectedBerries:
            if self.pickUpSound:
                self.pickUpSound.play()
            # Adds score based on how many berries were collected
            self.foxy.Pscore += 50 * len(collectedBerries)

        # Checks if Foxy reaches the picnic basket (goal)
        if pygame.sprite.spritecollide(self.foxy, self.goals, False):
            self.GMState = victory

        # Draws the level background
        if self.Background:
            self.window.blit(self.Background, (0, 0))
        else:
            self.window.fill(backgroundColors)

        # Draws all sprites (player, enemies, berries, platforms, etc.)
        self.allTheGameSprites.draw(self.window)

        # Draws slash effect if active
        if self.slashActive:
            now = pygame.time.get_ticks()
            if now - self.slashStartTime < self.slashDuration:
                self.window.blit(self.slashImage, self.slashRect)
            else:
                self.slashActive = False

        # Draws HUD (score, lives, and timer)
        Timeleft = self.timer.timeLeft()
        gameHudText = f"Score: {self.foxy.Pscore} Lives: {self.foxy.Plives} Time: {Timeleft}"
        hudSurface = self.font.render(gameHudText, True, GameHudColor)
        self.window.blit(hudSurface, (20, 20))

        # Flips the display and limit FPS
        pygame.display.flip()
        self.clock.tick(framesPerSecond)

    # Game Over Screen, shown when Foxy loses all lives or it out of time
    def gameOverLoop(self):
        # Handle events while on the game over screen
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Any key returns to the main menu
            if event.type == pygame.KEYDOWN:
                self.GMState = gameMenu

        # Draw either title background or fallback color
        if self.tittleBackground:
            self.window.blit(self.tittleBackground, (0, 0))
        else:
            self.window.fill((10, 20, 30))

        massege = self.font.render("Night night little fox - GAME OVER", True, colorWhite)
        prompt2 = self.font.render("Press any key to return to the menu", True, GameHudColor)

        # Center the text on the screen
        self.window.blit(massege, (gameWidth // 2 - massege.get_width() // 2, gameHeight // 3))
        self.window.blit(prompt2, (gameWidth // 2 - prompt2.get_width() // 2, gameHeight // 2))

        pygame.display.flip()
        self.clock.tick(framesPerSecond)

    # Pause Screen, it freezes the gameplay and lets the player think
    def pausedLoop(self):
        # Stay in this loop while the game is paused
        while self.GMState == pausedMenu:
            for event2 in pygame.event.get():
                if event2.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                # Only check keys when a KEYDOWN event happens
                if event2.type == pygame.KEYDOWN:
                    # Resume game
                    if event2.key == pygame.K_p:
                        self.GMState = playing
                        return
                    # Go back to main menu
                    if event2.key == pygame.K_ESCAPE:
                        self.GMState = gameMenu
                        return

            # Draw either the level background or a fallback color
            if self.Background:
                self.window.blit(self.Background, (0, 0))
            else:
                self.window.fill(backgroundColors)

            # Draws all game sprites behind the pause overlay
            self.allTheGameSprites.draw(self.window)

            # Dark transparent overlay to show it's paused
            overlay = pygame.Surface((gameWidth, gameHeight), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            self.window.blit(overlay, (0, 0))

            # Pauses text/message
            pausedtext = self.font.render("Time to strategize, little fox. Take a minute to think over our options.",True,colorWhite)
            prompt3 = self.font.render("Press P to resume playing the game, ESC for the menu",True,GameHudColor)

            # Centers both messages
            self.window.blit(pausedtext,(gameWidth // 2 - pausedtext.get_width() // 2, gameHeight // 3))
            self.window.blit(prompt3,(gameWidth // 2 - prompt3.get_width() // 2, gameHeight // 2))

            pygame.display.flip()
            self.clock.tick(framesPerSecond)


    # Victory Screen, shown when Foxy reaches the picnic basket
    def victoryLoop(self):
        # Handles events while on the victory screen
        for evt in pygame.event.get():
            if evt.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Any key sends the player back to the main menu
            if evt.type == pygame.KEYDOWN:
                self.GMState = gameMenu

        # Draws background for victory screen
        if self.Background:
            self.window.blit(self.Background, (0, 0))
        else:
            self.window.fill((0, 60, 0))

        massege2 = self.font.render(
            "Nice work little fox, we reached the picnic basket!",
            True,
            colorWhite
        )
        prompt3 = self.font.render(
            "Press any key to return to the menu",
            True,
            GameHudColor
        )

        # Center victory text on the screen
        self.window.blit(massege2,(gameWidth // 2 - massege2.get_width() // 2, gameHeight // 3))
        self.window.blit(prompt3,(gameWidth // 2 - prompt3.get_width() // 2, gameHeight // 2))

        pygame.display.flip()
        self.clock.tick(framesPerSecond)
