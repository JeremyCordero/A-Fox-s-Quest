import pygame
from items.settings import foxyJumpGravity, foxyrunningSpeed, foxyJumpSpeed, gameWidth # Gives access to foxys settings variables and game width
# Foxy Class – The main player character of the game
# Handles movement, jumping, gravity, attacking, and collisions
class Foxy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        # Trying to loading Foxy's image, otherwise make a fallback square
        try:
            img = pygame.image.load("fox.png").convert_alpha()
            self.image = pygame.transform.scale(img, (40, 40))
        except:
            self.image = pygame.Surface((40, 40))
            self.image.fill((255, 100, 50))

        # Player hitbox and starting position
        self.rect = self.image.get_rect(topleft=(x, y))

        # Player movement variables
        self.velocityX = 0
        self.velocityY = 0
        self.onTheGround = False  # True when Foxy is touching a platform

        # Player stats
        self.Plives = 3
        self.Pscore = 0

        # To know which direction Foxy is looking (used for attack box)
        self.facingRight = True

   
    # Handles all player inputs for movement and jumping
    def handleThePlayersInputs(self):
        keyboardKeys = pygame.key.get_pressed()
        self.velocityX = 0  # Resets horizontal movement every frame

        # Move left
        if keyboardKeys[pygame.K_LEFT] or keyboardKeys[pygame.K_a]:
            self.velocityX = -foxyrunningSpeed
            self.facingRight = False

        # Move right
        if keyboardKeys[pygame.K_RIGHT] or keyboardKeys[pygame.K_d]:
            self.velocityX = foxyrunningSpeed
            self.facingRight = True

        # Jump (only if standing on the ground)
        if (keyboardKeys[pygame.K_j] or keyboardKeys[pygame.K_w] or keyboardKeys[pygame.K_UP]) and self.onTheGround:
            self.velocityY = foxyJumpSpeed
            self.onTheGround = False

    # Player (foxy) Attack, we creates an visible hitbox in front of Foxy
    def foxyAttack(self, animalsOfTheForest):
        attackWidth = 40  # Size of the attack box

        # Attack box appears on the side Foxy is facing
        if self.facingRight:
            attackBox = pygame.Rect(
                self.rect.right,
                self.rect.top,
                attackWidth,
                self.rect.height,
            )
        else:
            attackBox = pygame.Rect(
                self.rect.left - attackWidth,  # extends to the left
                self.rect.top,
                attackWidth,
                self.rect.height,
            )

        defeatedAnimalCount = 0

        # Checks if the attack box hits any animal
        for animals in animalsOfTheForest:
            if attackBox.colliderect(animals.rect):
                defeated = animals.takeDamageFormPlayer()

                # If the animal dies, remove it and add score
                if defeated:
                    animals.kill()
                    self.Pscore += 100
                    defeatedAnimalCount += 1

                return defeatedAnimalCount  # Only hits one at a time

    
    # Applying gravity constantly while Foxy is in the air
    def applyingJumpGravity(self):
        self.velocityY += foxyJumpGravity

        # we prevent foxy form falling too fast
        if self.velocityY > 20:
            self.velocityY = 20

    # Allows the Player (foxy) to move horizontally and collision-check with platforms
    def horizontalMovement(self, platforms):
        self.rect.x += self.velocityX

        # Check collisions with every platform
        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                # Moving right → stop at left side of platform
                if self.velocityX > 0:
                    self.rect.right = platform.rect.left
                # Moving left → stop at right side of platform
                elif self.velocityX < 0:
                    self.rect.left = platform.rect.right

        # Keep Foxy inside the screen boundaries
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > gameWidth:
            self.rect.right = gameWidth

    
    # Vertical movement (jumping + falling) + platform collision
    def vertificalMovement(self, platforms):
        self.applyingJumpGravity()
        self.rect.y += self.velocityY
        self.onTheGround = False  # Reset before checking collisions

        for platform in platforms:
            if self.rect.colliderect(platform.rect):

                # Falling downward onto a platform
                if self.velocityY > 0:
                    self.rect.bottom = platform.rect.top
                    self.velocityY = 0
                    self.onTheGround = True

                # Hitting platform from below (jumping upwards)
                elif self.velocityY < 0:
                    self.rect.top = platform.rect.bottom
                    self.velocityY = 0


    # Update Foxy movement and gravity his every frame
    def update(self, platforms):
        self.horizontalMovement(platforms)
        self.vertificalMovement(platforms)

        
            