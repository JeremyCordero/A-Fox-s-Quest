import pygame
import math

# BaseAnimal – Parent class for all forest enemies, it handles movement, damage, flashing red on hit, and HP
class BaseAnimal(pygame.sprite.Sprite):
    def __init__(
        self, 
        x, y, 
        leftMovementLimit, rightmovementLimit, 
        speed=2,
        imageFile=None, 
        size=(40,40), 
        color=(200,50,50),
        damage=1,
        hp=1
    ):
        super().__init__()

        # Try loading an image for the enemy, fallback is a colored square
        if imageFile:
            try:
                image = pygame.image.load(imageFile).convert_alpha()
                self.image = pygame.transform.scale(image, size)
            except:
                self.image = pygame.Surface(size)
                self.image.fill(color)
        else:
            self.image = pygame.Surface(size)
            self.image.fill(color)

        # Stores a clean copy of the sprite for resetting after flashing red
        self.baseImage = self.image.copy()

        # Enemy's hitbox and starting position
        self.rect = self.image.get_rect(topleft=(x, y))

        # Movement area (walk left and right within these values)
        self.leftMovementLimit = leftMovementLimit
        self.rightmovementLimit = rightmovementLimit
        self.speed = speed  # Movement speed

        # Enemy stats
        self.damage = damage  # How much damage it deals to Foxy
        self.hp = hp          # How many hits it can take

        # Red flash timer (shows when the enemy takes damage)
        self.redFlash = 0

    
    # Default enemy behavior each frame:
    #   Move left and right
    #   Reverse direction at limits
    #   Flash red when hit
    def update(self, *args):
        # Move enemy horizontally
        self.rect.x += self.speed

        # Reverses direction if reaching movement boundaries
        if self.rect.x < self.leftMovementLimit or self.rect.x > self.rightmovementLimit:
            self.speed *= -1

        # Handles damage flashing effect
        rightNow = pygame.time.get_ticks()

        # Flash red while the timer is active
        if rightNow < self.redFlash:
            self.image = self.baseImage.copy()
            overlay = pygame.Surface(self.image.get_size(), pygame.SRCALPHA)
            overlay.fill((255, 0, 0, 120))  # translucent red overlay
            self.image.blit(overlay, (0, 0))
        else:
            # After flashing, restore original sprite
            self.image = self.baseImage.copy()

    
    # Receive damage from Foxy's attack, it will return True if the enemy's HP reaches zero and should be removed
    def takeDamageFormPlayer(self, amountOfHP=1):
        self.hp -= amountOfHP
        # Flash of red for 150 ms
        self.redFlash = pygame.time.get_ticks() + 150

        # If HP is 0 or less → enemy is defeated
        return self.hp <= 0



# Deer, a medium-speed enemy, moderate HP, simple behavior
class Deer(BaseAnimal):
    def __init__(self, x, y, leftMovementLimit, rightmovementLimit):
        super().__init__(
            x, y,
            leftMovementLimit, rightmovementLimit,
            speed=2,
            imageFile="deer.png",
            size=(50, 40),
            color=(160, 120, 80),
            damage=1,
            hp=2
        )



# Rabbit, a fast enemy with hopping animation
class Rabbit(BaseAnimal):
    def __init__(self, x, y, leftMovementLimit, rightmovementLimit):
        super().__init__(
            x, y,
            leftMovementLimit, rightmovementLimit,
            speed=4,
            imageFile="rabbit.png",
            size=(35, 30),
            color=(230, 230, 230),
            damage=1,
            hp=1
        )

        # Base vertical position used for hopping up/down
        self.baseY = y


    # Rabbit override:Keeps original movement but adds sinusoidal "hopping"--
    def update(self, *args):
        # Keeps base enemy movement (left/right + flashing)
        super().update(*args)

        # Simple sine-wave jump cycle
        J = pygame.time.get_ticks() / 150.0
        Jump = int(6 * math.sin(J))

        # Applying the hopping effect
        self.rect.y = self.baseY + Jump



# Bear, ist a slow but strong enemy with high HP
class Bear(BaseAnimal):
    def __init__(self, x, y, leftMovementLimit, rightmovementLimit):
        super().__init__(
            x, y,
            leftMovementLimit, rightmovementLimit,
            speed=1,
            imageFile="Bear.png",
            size=(60, 50),
            color=(230, 230, 230),
            damage=2,
            hp=3
        )
