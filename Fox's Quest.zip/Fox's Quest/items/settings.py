# Game window settings
gameWidth = 1000
gameHeight = 600
framesPerSecond = 60
# foxes movement
foxyJumpGravity = 0.6
foxyrunningSpeed = 6
foxyJumpSpeed = -12
# background and hud colors
backgroundColors = (50,150,80)
colorWhite = (255,255,255)
GameHudColor = (255,100,50)
# level timer
levelstimeLimit = 160
