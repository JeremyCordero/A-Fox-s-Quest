import pygame 

# levelsTimer – Its as simple countdown timer used for each level, keeps track of how much time has passed and how much is left
class levelsTimer:
    def __init__(self, totalAmountOfSeconds):
        # How many seconds the level will last
        self.totalAmountOfSeconds = totalAmountOfSeconds
        
        # Stores the exact moment the timer starts (in ms)
        self.startTimer = pygame.time.get_ticks()

    # Resets the timer back to full time
    def resetTimer(self, newSeconds=None):
        # If a new duration is provided, update the total seconds
        if newSeconds is not None:
            self.totalAmountOfSeconds = newSeconds

        # Restart the internal clock from the current moment
        self.startTimer = pygame.time.get_ticks()

    # Returns how many seconds are left before the timer hits zero
    def timeLeft(self):
        # Current time in milliseconds
        rightNow = pygame.time.get_ticks()

        # How many seconds have passed since the level started
        timePassed = (rightNow - self.startTimer) // 1000

        # Remaining seconds ( it will never return negative numbers)
        return max(0, self.totalAmountOfSeconds - timePassed)
      
    # Returns True if the countdown has reached 0 seconds
    def gameTimeIsUP(self):
        return self.timeLeft() == 0

      