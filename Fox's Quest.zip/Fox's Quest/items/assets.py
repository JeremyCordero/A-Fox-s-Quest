import pygame


# Berry Class, it holds a small collectible that increases Foxy's score
class Berry(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        # Trying loading the berry sprite, otherwise create a fallback
        try:
            image = pygame.image.load("berry.png").convert_alpha()
            self.image = pygame.transform.scale(image, (20, 20))
        except:
            # We fallback red square if sprite not found
            self.image = pygame.Surface((20, 20))
            self.image.fill((200, 0, 0))

        # Center the berry at the given position
        self.rect = self.image.get_rect(center=(x, y))


# Picnic Class, itsn main Goal object that ends the level when reached
class Picknic(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        # Trying loading the picnic basket sprite
        try:
            image = pygame.image.load("picnic.png").convert_alpha()
            self.image = pygame.transform.scale(image, (64, 64))
        except:
            # We fallback brown square if sprite not found
            self.image = pygame.Surface((64, 64))
            self.image.fill((150, 100, 0))

        # Placing the picnic basket at its center position
        self.rect = self.image.get_rect(center=(x, y))



# Platform Class, its the Ground or floating surfaces Foxy can stand on
class Platforms(pygame.sprite.Sprite):
    def __init__(self, x, y, Pwidth, Pheight):
        super().__init__()

        # Trying loading a platform image and resize it
        try:
            platform = pygame.image.load("platform.png").convert_alpha()
            self.image = pygame.transform.scale(platform, (Pwidth, Pheight))
        except:
            # We fallback platform: simple brown rectangle
            self.image = pygame.Surface((Pwidth, Pheight))
            self.image.fill((80, 50, 20))

        # We Position the platform by its top-left corner
        self.rect = self.image.get_rect(topleft=(x, y))
