from game import Game
if __name__== "__main__":# Entry point of the program
    game = Game()# Creates a Game instance
    game.run() # Starts the game loop